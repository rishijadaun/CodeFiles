<?php
/**
 * The template for displaying comments
 *
 * This is the template that displays the area of the page that contains both the current comments
 * and the comment form.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package codefiles
 */

/*
 * If the current post is protected by a password and
 * the visitor has not yet entered the password we will
 * return early without loading the comments.
 */
 if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
if ( post_password_required() ) {
	return;
}
?>
<section id="about" class="bg-[#f3f4fe]  py-4 px-3 sm:px-6 md:p-6 lg:py-8 lg:px-10">
<div id="comments" class="comments-area">
	<?php
	// You can start editing here -- including this comment!
	if ( have_comments() ) :
		?>
		<h4 class="comments-title mb-6 text-2xl font-bold text-dark sm:text-2xl sm:leading-snug 2xl:text-[20px]">
			<?php
			$codefiles_comment_count = get_comments_number();
			if ( '1' === $codefiles_comment_count ) {
				printf(
					/* translators: 1: title. */
					esc_html__( 'One thought on &ldquo;%1$s&rdquo;', 'codefiles' ),
					'<span>' . wp_kses_post( get_the_title() ) . '</span>'
				);
			} else {
				printf( 
					/* translators: 1: comment count number, 2: title. */
					esc_html( _nx( 'There are %1$s thought on &ldquo;%2$s&rdquo;', '%1$s thoughts on &ldquo;%2$s&rdquo;', $codefiles_comment_count, 'comments title', 'codefiles' ) ),
					number_format_i18n( $codefiles_comment_count ),
					'<span>' . wp_kses_post( get_the_title() ) . '</span>'
				);
			}
			?>
		</h4><!-- .comments-title -->
        <hr>
        <br>
		<?php the_comments_navigation(); ?>

		<ul class="comment-list">
			<?php
			wp_list_comments(
				array(
					'style'      => 'li',
					'short_ping' => true,
				)
			);
			?>
		</ul><!-- .comment-list -->

		<?php
		the_comments_navigation();

		// If comments are closed and there are comments, let's leave a little note, shall we?
		if ( ! comments_open() ) :
			?>
			<p class="no-comments"><?php esc_html_e( 'Comments are closed.', 'codefiles' ); ?></p>
			<?php
		endif;

	endif; // Check for have_comments().
// display comments
//	comment_form();
	?>
   </div><!-- #comments -->
</section>
