<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
/**
 * Template for displaying search forms
 *
 * @package  codefiles
 * @since    1.0
 */
 if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<form role="search" method="get" class="search-form mt-3" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label class="form-label">
		<span class="screen-reader-text"  for='s'><?php echo esc_html_x( 'Search for:', 'label', 'codefiles' ); ?></span>
		<input type="search" class="bordder-[#E9EDF4] w-full mb-2 rounded-md border bg-[#FCFDFE] py-3 px-5 text-base text-body-color placeholder-[#ACB6BE] outline-none transition focus:border-primary focus-visible:shadow-none"
		       placeholder="<?php echo esc_attr_x( 'Search&hellip;', 'placeholder', 'codefiles' ); ?>"
		       value="<?php echo get_search_query() ?>" name="s"
		       title="<?php echo esc_attr_x( 'Search for:', 'label', 'codefiles' ); ?>"/>
	</label>
	<button type="submit" class="mb-4  mt-2 h-[50px] w-full cursor-pointer rounded bg-[#13C296] text-center text-sm font-medium text-white transition duration-300 ease-in-out hover:bg-opacity-90 hover:shadow-lg">
		<span class="search-btn-text">
			<?php echo _x( 'Search', 'submit button', 'codefiles' ); ?>
		</span>
	</button>
</form>