<?php
/**
 * codefiles functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package codefiles
 */
 
if ( ! defined( 'CODFILES_VERSION' ) ) {
	// Replace the version number of the theme on each release.
	define( 'CODFILES_VERSION', '1.0.0' );
}

/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
 if ( ! function_exists( 'codefiles_wptheme_setup') ) :
function codefiles_wptheme_setup() {
	/*
		* Make theme available for translation.
		* Translations can be filed in the /languages/ directory.
		* If you're building a theme based on codefiles, use a find and replace
		* to change 'codefiles' to the name of your theme in all the template files.
		*/
	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );
	/*
		* Let WordPress manage the document title.
		* By adding theme support, we declare that this theme does not use a
		* hard-coded <title> tag in the document head, and expect WordPress to
		* provide it for us.
		*/
	add_theme_support( 'title-tag' );
    // Load default block styles.
    add_theme_support( 'responsive-embeds' );
    add_theme_support( 'wp-block-styles' );
    add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'script', 'style' ) );
     add_theme_support( 'custom-header' );
        $defaults = array(
        'default-color'          => 'ffffff',
        'default-image'          => '',
        'default-repeat'         => 'repeat',
        'default-position-x'     => 'left',
        'default-position-y'     => 'top',
        'default-size'           => 'auto',
        'default-attachment'     => 'scroll',
        'wp-head-callback'       => '_custom_background_cb',
        'admin-head-callback'    => '',
        'admin-preview-callback' => ''
    );
    add_theme_support( 'custom-background', $defaults);
    add_theme_support( 'align-wide' );
    add_editor_style ( 'style.css' );
    add_theme_support( 'woocommerce' );
	/*
		* Enable support for Post Thumbnails on posts and pages.
		*
		* @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		*/
	add_theme_support( 'post-thumbnails' );
	add_image_size( 'codefiles_post_subthumbnail', 80, 80, true );
    add_image_size( 'codefiles_post_blog_thumbnail', 408, 272, true );

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus(
		array(
			'primary' => esc_html__( 'Primary', 'codefiles'),
            'secondary' => esc_html__( 'Secondary', 'codefiles'),
		)
	);
	/*
		* Switch default core markup for search form, comment form, and comments
		* to output valid HTML5.
		*/
	add_theme_support(
		'html5',
		array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'style',
			'script',
		)
	);

	// Set up the WordPress core custom background feature.
	add_theme_support(
		'custom-background',
		apply_filters(
			'codefiles_custom_background_args',
			array(
				'default-color' => 'ffffff',
				'default-image' => '',
			)
		)
	);

	// Add theme support for selective refresh for widgets.
	add_theme_support( 'customize-selective-refresh-widgets' );

	/**
	 * Add support for core custom logo.
	 *
	 * @link https://codex.wordpress.org/Theme_Logo
	 */
     add_theme_support('custom-logo', array(
            'width' => 250,
            'height' => 250,
            'flex-height' => true,
    		'flex-width'  => true,
        ));
}
endif;
add_action( 'after_setup_theme', 'codefiles_wptheme_setup' );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
 if ( ! function_exists( 'codefiles_widgets_init') ) :
function codefiles_widgets_init() {
	register_sidebar(
		array(
			'name'          => esc_html__( 'Sidebar Blog', 'codefiles' ),
			'id'            => 'sidebar-1',
			'description'   => esc_html__( 'Add widgets here.', 'codefiles' ),
			'before_widget' => '<section id="%1$s" class="widget w-full px-4 %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title wow fadeInUp relative pb-5 text-2xl font-semibold text-dark sm:text-[28px]">',
			'after_title'   => '</h2>',
		)
	);
	register_sidebar(
		array(
			'name'          => esc_html__( 'Footer First', 'codefiles' ),
			'id'            => 'sidebar-2',
			'description'   => esc_html__( 'Add widgets here.', 'codefiles' ),
			'before_widget' => '<section id="%1$s" class="widget mb-10 w-full %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title mb-9 text-lg font-semibold text-white">',
			'after_title'   => '</h2>',
		)
	);
	register_sidebar(
		array(
			'name'          => esc_html__( 'Footer Second', 'codefiles' ),
			'id'            => 'sidebar-3',
			'description'   => esc_html__( 'Add widgets here.', 'codefiles' ),
			'before_widget' => '<section id="%1$s" class="widget mb-10 w-full %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title mb-9 text-lg font-semibold text-white">',
			'after_title'   => '</h2>',
		)
	);
	register_sidebar(
		array(
			'name'          => esc_html__( 'Footer Third', 'codefiles' ),
			'id'            => 'sidebar-4',
			'description'   => esc_html__( 'Add widgets here.', 'codefiles' ),
			'before_widget' => '<section id="%1$s" class="widget mb-10 w-full %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title mb-9 text-lg font-semibold text-white">',
			'after_title'   => '</h2>',
		)
	);
	register_sidebar(
		array(
			'name'          => esc_html__( 'Footer Four', 'codefiles' ),
			'id'            => 'sidebar-5',
			'description'   => esc_html__( 'Add widgets here.', 'codefiles' ),
			'before_widget' => '<section id="%1$s" class="widget mb-10 w-full %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title mb-9 text-lg font-semibold text-white">',
			'after_title'   => '</h2>',
		)
	);
	register_sidebar(
		array(
			'name'          => esc_html__( 'Footer Fifth', 'codefiles' ),
			'id'            => 'sidebar-6',
			'description'   => esc_html__( 'Add widgets here.', 'codefiles' ),
			'before_widget' => '<section id="%1$s" class="widget mb-10 w-full %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title mb-9 text-lg font-semibold text-white">',
			'after_title'   => '</h2>',
		)
	);
	register_sidebar(
		array(
			'name'          => esc_html__( 'Footer Bottom', 'codefiles' ),
			'id'            => 'sidebar-7',
			'description'   => esc_html__( 'Add widgets here.', 'codefiles' ),
			'before_widget' => '<section id="%1$s" class="widget mb-10 w-full %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title mb-9 text-lg font-semibold text-white">',
			'after_title'   => '</h2>',
		)
	);
}
endif;
add_action( 'widgets_init', 'codefiles_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
if ( ! function_exists( 'codefiles_scripts') ) :
function codefiles_scripts() {
	wp_enqueue_style( 'codefiles-style', get_stylesheet_uri(), array(), CODFILES_VERSION );
	wp_style_add_data( 'codefiles-style', 'rtl', 'replace' );
	
	wp_enqueue_style( 'codefiles-tailwind', get_template_directory_uri() . '/assets/css/tailwind.css', array(), CODFILES_VERSION );
	wp_enqueue_style( 'codefiles-tailwind', get_template_directory_uri() . '/assets/css/theme-style.css', array(), CODFILES_VERSION );
	wp_enqueue_script( 'codefiles-main', get_template_directory_uri() . '/assets/js/main.js', array(), CODFILES_VERSION, true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
endif;
add_action( 'wp_enqueue_scripts', 'codefiles_scripts' );

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';


// add classes to wp_list_pages in header menu
if ( ! function_exists( 'codefiles_wp_list_pages_filter') ) :
function codefiles_wp_list_pages_filter($output) {
   $output = str_replace('page_item', 'page_item group relative', $output);
  // $output = str_replace('current_page_item', 'current_page_item submenu-item', $output);
   $output = str_replace('relative_has_children', 'relative_has_children submenu-item', $output);
   $output = str_replace('<a ', '<a class="ud-menu-scroll mx-8 flex py-2 text-base text-dark group-hover:text-primary lg:mr-0 lg:ml-7 lg:inline-flex lg:py-6 lg:px-0 lg:text-white lg:group-hover:text-white lg:group-hover:opacity-70 xl:ml-10" ', $output);
   $output = str_replace('<ul ', '<ul class="submenu relative top-full left-0 hidden w-[250px] rounded-sm bg-white p-4 transition-[top] duration-300 group-hover:opacity-100 lg:invisible lg:absolute lg:top-[110%] lg:block lg:opacity-0 lg:shadow-lg lg:group-hover:visible lg:group-hover:top-full" ', $output);
  return $output;
}
endif;
add_filter('wp_list_pages', 'codefiles_wp_list_pages_filter');

// add classes to wp_list_pages in header menu
if ( ! function_exists( 'codefiles_nav_menu_link_attributes') ) :
function codefiles_nav_menu_link_attributes($output) {
   $output = str_replace('menu-item', 'menu-item group relative', $output);
   $output = str_replace('current_page_parent', 'current_page_parent menu-item-has-children', $output);
   $output = str_replace('relative-has-children', 'relative-has-children submenu-item group relative', $output);
   $output = str_replace('<a ', '<a class="ud-menu-scroll mx-8 flex py-2 text-base text-dark group-hover:text-primary lg:mr-0 lg:ml-7 lg:inline-flex lg:py-6 lg:px-0 lg:text-white lg:group-hover:text-white lg:group-hover:opacity-70 xl:ml-10" ', $output);
   $output = str_replace('<ul ', '<ul class="submenu relative top-full left-0 hidden w-[250px] rounded-sm bg-white p-4 transition-[top] duration-300 group-hover:opacity-100 lg:invisible lg:absolute lg:top-[110%] lg:block lg:opacity-0 lg:shadow-lg lg:group-hover:visible lg:group-hover:top-full" ', $output);
  return $output;
}
endif;
add_filter('wp_nav_menu', 'codefiles_nav_menu_link_attributes');


// Block Library CSS from WordPress 5.0
add_filter( 'should_load_separate_core_block_assets', '__return_true' );

if ( function_exists( 'register_block_style' ) ) {
    register_block_style(
        'core/quote',
        array(
            'name'         => 'blue-quote',
            'label'        => __( 'Blue Quote', 'codefiles' ),
            'is_default'   => true,
            'inline_style' => '.wp-block-quote.is-style-blue-quote { color: blue; }',
        )
    );
}
if ( ! function_exists( 'codefiles_wpdocs_register_block_patterns') ) :
function codefiles_wpdocs_register_block_patterns() {
        register_block_pattern(
            'wpdocs/my-codefiles',
            array(
                'title'         => __( 'My First Block Pattern', 'codefiles' ),
                'description'   => _x( 'This is my first block pattern', 'Block pattern description', 'codefiles' ),
                'content'       => '<!-- wp:paragraph --><p>A single paragraph block style</p><!-- /wp:paragraph -->',
                'categories'    => array( 'text' ),
                'keywords'      => array( 'cmt', 'data', 'codefiles' ),
                'viewportWidth' => 800,
            )
        );
}
endif;
add_action( 'init', 'codefiles_wpdocs_register_block_patterns' );

// Keyboard Navigation
if ( ! function_exists( 'codefeiles_skip_link_focus_fix') ) :
function codefeiles_skip_link_focus_fix() {
	?>
	<script>
	/(trident|msie)/i.test(navigator.userAgent)&&document.getElementById&&window.addEventListener&&window.addEventListener("hashchange",function(){var t,e=location.hash.substring(1);/^[A-z0-9_-]+$/.test(e)&&(t=document.getElementById(e))&&(/^(?:a|select|input|button|textarea)$/i.test(t.tagName)||(t.tabIndex=-1),t.focus())},!1);
	</script>
<?php
}
endif;
add_action( 'wp_print_footer_scripts', 'codefeiles_skip_link_focus_fix' );

// Post View Count 
if ( ! function_exists( 'codefeiles_gt_get_post_view') ) :
function codefeiles_gt_get_post_view() {
    $count = get_post_meta( get_the_ID(), 'post_views_count', true );
    return "$count views";
}
endif;
if ( ! function_exists( 'codefeiles_gt_set_post_view') ) :
function codefeiles_gt_set_post_view() {
    $key = 'post_views_count';
    $post_id = get_the_ID();
    $count = (int) get_post_meta( $post_id, $key, true );
    $count++;
    update_post_meta( $post_id, $key, $count );

}
endif;
if ( ! function_exists( 'codefeiles_gt_posts_column_views') ) :
function codefeiles_gt_posts_column_views( $columns ) {
    $columns['post_views'] = 'Views';
    return $columns;
}
endif;
if ( ! function_exists( 'codefeiles_gt_posts_custom_column_views') ) :
function codefeiles_gt_posts_custom_column_views( $column ) {

    if ( $column === 'post_views') {
        echo codefeiles_gt_get_post_view();
    }
}
endif;
add_filter( 'manage_posts_columns', 'codefeiles_gt_posts_column_views' );
add_action( 'manage_posts_custom_column', 'codefeiles_gt_posts_custom_column_views' );


//  Add custom classes to list item "li a" */
// if ( ! function_exists( 'add_link_atts') ) :
// function add_link_atts($atts) {
//   $atts['class'] = "ud-menu-scroll mx-8 flex py-2 text-base text-dark group-hover:text-primary lg:mr-0 lg:ml-7 lg:inline-flex lg:py-6 lg:px-0 lg:text-white lg:group-hover:text-white lg:group-hover:opacity-70 xl:ml-12";
//   return $atts;
// }
// endif;
// add_filter( 'nav_menu_link_attributes', 'add_link_atts');

/* Add custom classes to list item "li" */

// function _namespace_menu_item_class( $classes, $item ) {       
//     $classes[] = "nav-item"; // you can add multiple classes here
//     return $classes;
// } 

// add_filter( 'nav_menu_css_class' , '_namespace_menu_item_class' , 10, 2 );