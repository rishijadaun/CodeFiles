=== CodeFiles ===

Contributors: xolodevelopers
Tags: custom-background, custom-logo, custom-menu, featured-images, threaded-comments, translation-ready
Theme URI:
Requires at least: 4.5
Tested up to: 5.4
Requires PHP: 7.0
Stable tag: 1.0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

CodeFiles is a beautifull theme which is based on tailwind css and lightweight theme.

== Description ==

Description: Rapidly build modern websites without ever leaving your HTML. A modern, flexible, fast and truly multipurpose WordPress theme for any type of business website.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.


== License ==

CodeFiles WordPress Theme, Copyright 2022.
CodeFiles is licensed under the GNU General Public License v2 or later

More details [here](http://www.gnu.org/licenses/gpl-2.0.html).

= tailwindcss licence =
https://tailwindui.com/license
https://github.com/tailwindlabs/tailwindcss/blob/master/LICENSE

== Changelog ==

= 1.0  =
* Initial release

= 1.0.1  =
* Fix minor issue
