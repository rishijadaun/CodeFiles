<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
/**
 * Template part for displaying results in search pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package codefiles
 */
?>
<section class="wow fadeInUp relative z-10 mb-10 overflow-hidden rounded bg-primary bg-opacity-5 py-4 px-4 text-center sm:p-6 md:px-[40px]">
    <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    	<header class="entry-header">
    		<?php the_title( sprintf( '<h2 class="entry-title wow fadeInUp mb-8 text-2xl font-bold text-dark sm:text-[26px]"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>
    		<?php if ( 'post' === get_post_type() ) : ?>
    		<div class="entry-meta mb-2">
    			<?php
    			 if (function_exists('codefiles_posted_on')) { codefiles_posted_on(); } 
    			  if (function_exists('codefiles_posted_on')) { codefiles_posted_by(); }
    			?>
    		</div><!-- .entry-meta -->
    		<?php endif; ?>
    	</header><!-- .entry-header -->
    
    	<?php if (function_exists('codefiles_post_thumbnail')) { codefiles_post_thumbnail(); } ?>
    
    	<div class="entry-summary mb-4">
    		<?php the_excerpt(); ?>
    	</div><!-- .entry-summary -->
    
    	<footer class="entry-footer">
    		<?php if (function_exists('codefiles_entry_footer')) { codefiles_entry_footer(); } ?>
    	</footer><!-- .entry-footer -->
    </article><!-- #post-<?php the_ID(); ?> -->
</section>