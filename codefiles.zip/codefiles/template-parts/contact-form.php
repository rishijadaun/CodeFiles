<?php 
/* Template Name: Contact form */
get_header();
?>
<div class="ajax-form" style="padding-top:20%;">
  <div class="container">
    <div class=row>
      <div class="col-md-6 col-md-offset-3 form-box">
       <form action="" method="post" class="ajax" 
enctype="multipart/form-data">

         <h1>Ajax Form</h1>

         <label><b>Name</b></label>

          <input type="text" placeholder="Enter Your Name" name="name" 
required class="name">

         <label><b>Email</b></label>

         <input type="email" placeholder="Enter your Email" name="email" 
required class="email">

         <label><b>Message</b></label>

          <input type="text" placeholder="Message" name="message" 
required class="message"><hr>

            <div id="msg"></div>

              <input type = "submit" class="submitbtn" value="submit">

<div class="success_msg" style="display: none">Message 
Sent Successfully</div>

                  <div class="error_msg" style="display: none">Message 
Not Sent, There is some error.</div>

    </form>

   </div>

 </div>

</div>
<!--<div class="container mb-4 mt-4" style="margin-top:10%;">-->
<!--<form class="w-full uploaded-form-data" action="<?php echo admin_url('admin-ajax.php'); ?>">-->
<!--  <div class="flex flex-wrap -mx-3 mb-6">-->
<!--    <div class="w-full md:w-1/2 px-3 mb-6 md:mb-0">-->
<!--      <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="grid-first-name">-->
<!--        First Name-->
<!--      </label>-->
<!--      <input name="name" class="appearance-none block w-full bg-gray-200 text-gray-700 border border-red-500 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white" id="grid-first-name" type="text" placeholder="Jane">-->
<!--      <p class="text-red-500 text-xs italic">Please fill out this field.</p>-->
<!--    </div>-->
<!--    <div class="w-full md:w-1/2 px-3">-->
<!--      <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="grid-last-name">-->
<!--        Last Name-->
<!--      </label>-->
<!--      <input name="lname" class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500" id="grid-last-name" type="text" placeholder="Doe">-->
<!--    </div>-->
<!--  </div>-->
<!--  <div class="flex flex-wrap -mx-3 mb-6">-->
<!--    <div class="w-full px-3">-->
<!--      <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="grid-password">-->
<!--        Password-->
<!--      </label>-->
<!--      <input name="password" class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-gray-500" id="grid-password" type="password" placeholder="******************">-->
<!--      <p class="text-gray-600 text-xs italic">Make it as long and as crazy as you'd like</p>-->
<!--    </div>-->
<!--  </div>-->
<!--  <div class="flex flex-wrap -mx-3 mb-2">-->
<!--    <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">-->
<!--      <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="grid-city">-->
<!--        City-->
<!--      </label>-->
<!--      <input class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500" id="grid-city" type="text" placeholder="Albuquerque">-->
<!--    </div>-->
<!--    <input type="hidden" name="action" value="product_frm_action">-->
<!--	<?php wp_nonce_field( 'product_frm_action_nonce', 'product_frm_nonce' ); ?>-->
<!--    <button  class="my-1 inline-block rounded bg-[#13C296] py-4 px-6 text-base font-medium text-white transition hover:bg-opacity-90 md:px-9 lg:px-6 xl:px-9">Submit</button>-->
<!--  </div>-->
<!--</form>-->
<!--</div>-->
<script>
   jQuery(document).ready(function($){
$('form.ajax').on('submit', function(e){
   e.preventDefault();
   var that = $(this),
   url = that.attr('action'),
   type = that.attr('method');
   var name = $('.name').val();
   var email = $('.email').val();
   var message = $('.message').val();
   $.ajax({
      url: "<?php echo admin_url('admin-ajax.php'); ?>";,
      alert("Submitting to URL: " + url);
      type:"POST",
      dataType:'type',
      data: {
         action:'set_form',
         name:name,
         email:email,
         message:message,
    },   success: function(response){
        $(".success_msg").css("display","block");
     }, error: function(data){
         $(".error_msg").css("display","block");      }
   });
$('.ajax')[0].reset();
  });
});
</script>
<?php
get_footer();